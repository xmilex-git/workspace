# flaky TC 보고 — bug_bts_13242 잠금 덤프 시점 동기화 불안정

PR #8022의 gha-ci shell 테스트에서 `bug_bts_13242`가 실패하여 보고합니다. 다른 PR에서도 반복 관측되며, 잠금 개수만으로 lockdb 덤프 시점을 결정하는 TC의 동기화 문제로 판단합니다. 확인 및 안정화 부탁드립니다. 필요하면 수정 전 unstable 이관도 검토 부탁드립니다.

## 대상
`shell/_06_issues/_14_1h/bug_bts_13242/cases/bug_bts_13242.sh`

실패 검사: `bug_bts_13242-1`, `issue_13242.result_sorted`와 `issue_13242.answer_sorted` 비교

## 실패 내용 및 근거
- 대표 실패는 run `37168626427`, shell shard 16입니다.
- sorted diff에서 결과 쪽 `LOCK HOLDERS` 블록과 `dba.t1` 인스턴스 잠금이 하나 더 나타납니다. 원인 조사에서는 클래스 잠금 모드(`SCH_S_LOCK` 대비 `IX_LOCK`/`X_LOCK`)와 `IS_LOCK`의 Count(1 대비 4) 차이도 확인했습니다.
- 수집한 120개 run 중 9개 run, 서로 다른 PR 8개에서 실패했습니다.
- 관측 run: `36694232105`(#7901), `36701588264`(#7957), `36702541200`(#7977), `36703643879`(#7993), `36743148780`(#8001), `36795106556`(#7969), `36799634228`(#8059), `36986809351`(#7943), `37168626427`(#8022).

## 원인 및 수정 요청
TC의 `run_test_point`는 SQL을 백그라운드 csql에 보내고, `export_lockdb`는 1초 간격으로 lockdb를 실행해 `Current number of objects which are locked`가 기대 개수와 같아지면 덤프를 채택합니다. 같은 개수라고 같은 잠금 집합인 것은 아니므로, 잠금 획득 중간 상태나 이전 검사 정리 상태를 채택할 수 있습니다.

또한 현재 `lock_done.flag`는 덤프 후 rollback을 허용하는 신호이며, csql이 대상 SQL 실행을 완료했다는 신호는 아닙니다. `wait_pid_exit`도 60초 뒤 여전히 살아 있는 세션을 명시적으로 실패 처리하지 않습니다. 시점 동기화가 불완전하다는 판단은 이 소스와 관측 diff에 근거하며, 실패 시점의 세션 상태를 계측해 경합 경로까지 확정한 것은 아닙니다.

- 단순 개수 대신 기대하는 클래스·인스턴스·모드의 잠금 집합을 확인하거나, SQL 완료를 확인하는 세션 측 신호를 받은 뒤 트랜잭션을 유지한 상태로 덤프해 주세요. 파이프에 SQL을 썼다는 사실만으로 실행 완료를 간주하면 안 됩니다.
- 기대 상태 대기 타임아웃과 이전 세션 종료 실패를 명시적인 NOK로 처리하여 다음 검사로 잘못 진행하지 않도록 보강해 주세요.
- sleep 시간을 늘리거나 잠금 차이를 답지에서 없애기보다, 본래 잠금 검증은 유지하고 덤프 시점의 결정성을 확보하는 방향으로 수정 부탁드립니다.
- 수정 후 동일 엔진/TC revision 반복 실행으로 안정성을 확인 부탁드립니다.

## 참고 링크
- 대표 실패 run: https://github.com/CUBRID/cubrid/actions/runs/37168626427 (shell shard 16)
- 다른 PR의 실패 예: https://github.com/CUBRID/cubrid/actions/runs/36694232105
- TC 소스: https://github.com/CUBRID/cubrid-testcases-private-ex/blob/9e9f773d1/shell/_06_issues/_14_1h/bug_bts_13242/cases/bug_bts_13242.sh
